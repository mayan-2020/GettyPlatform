import { ArrowLeft, MapPin } from "lucide-react"

export default function CreateAndManageGeofences() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/geofencing-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Geofencing Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <MapPin className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">How to create and manage geofences</h1>
          <p className="text-lg text-slate-600">
            Learn the basics of creating virtual boundaries and managing them effectively in your fleet tracking system.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Creating a New Geofence</h2>
          <p>
            Geofences are virtual boundaries that you can set up around specific geographic areas. When vehicles enter
            or exit these areas, the system can trigger various actions such as alerts, notifications, or reports.
          </p>

          <h3>Step 1: Access the Geofence Window</h3>
          <ol>
            <li>Navigate to the main menu and select "Geofences"</li>
            <li>Click on "Create New Geofence" button</li>
            <li>Choose the type of geofence you want to create (circular, polygon, or route-based)</li>
          </ol>

          <h3>Step 2: Define the Geofence Area</h3>
          <ol>
            <li>Use the map interface to select your desired location</li>
            <li>For circular geofences: Click on the center point and drag to set the radius</li>
            <li>For polygon geofences: Click multiple points to create a custom shape</li>
            <li>Adjust the boundaries as needed by dragging the control points</li>
          </ol>

          <h3>Step 3: Configure Geofence Settings</h3>
          <ul>
            <li>
              <strong>Name:</strong> Give your geofence a descriptive name
            </li>
            <li>
              <strong>Description:</strong> Add details about the purpose of this geofence (optional)
            </li>
          </ul>

          <h2>Managing Existing Geofences</h2>

          <h3>Editing Geofences</h3>
          <p>To modify an existing geofence:</p>
          <ol>
            <li>Go to the Geofence list</li>
            <li>Click on the geofence you want to edit</li>
            <li>Make your changes to the boundary, settings, or properties</li>
            <li>Save your changes</li>
          </ol>

          <h3>Deleting Geofences</h3>
          <p>
            To remove a geofence that's no longer needed, select it from the list and click the delete button. Note that
            this action cannot be undone, so make sure you really want to remove the geofence.
          </p>

          <h2>Best Practices</h2>
          <ul>
            <li>Use descriptive names that clearly indicate the purpose and location</li>
            <li>Regularly review and update your geofences to ensure they remain relevant</li>
            <li>Test geofences with a few vehicles before applying them to your entire fleet</li>
            <li>Consider the size of your geofences - too small may cause frequent false alerts</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
