import { ArrowLeft, Bell } from "lucide-react"

export default function EmailSMSAlerts() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/geofencing-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Geofencing Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Bell className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">
            Generate Email and Fleet App Alerts Based on Geofence Alerts
          </h1>
          <p className="text-lg text-slate-600">
            Set up automated notifications when vehicles enter or exit geofenced areas to stay informed about your
            fleet's movements.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Setting Up Geofence Alerts</h2>
          <p>
            Geofence alerts allow you to receive immediate notifications when vehicles cross virtual boundaries. You can
            configure different types of alerts including email and in-app notifications.
          </p>

          <h3>Configuring Email Alerts</h3>
          <ol>
            <li>Navigate to the event that contains your geofence</li>
            <li>In section 5. notifications, enable notifications</li>
            <li>Add recipient email addresses (you can add multiple recipients)</li>
            <li>
              Choose the trigger events:
              <ul>
                <li>Vehicle enters geofence</li>
                <li>Vehicle exits geofence</li>
                <li>Vehicle dwells in geofence for specified time</li>
              </ul>
            </li>
            <li>Customize the email template with relevant information</li>
          </ol>

          <h3>Fleet App Notifications</h3>
          <p>For users with the mobile fleet app:</p>
          <ul>
            <li>Enable "Push Notifications" in the alert settings</li>
            <li>Select which app users should receive notifications</li>
            <li>Configure notification priority levels</li>
            <li>Set up custom notification sounds if needed</li>
          </ul>

          <h2>Alert Customization Options</h2>

          <h3>Message Templates</h3>
          <p>You can customize alert messages to include:</p>
          <ul>
            <li>Vehicle name or ID</li>
            <li>Driver name</li>
            <li>Geofence name</li>
            <li>Timestamp of the event</li>
            <li>GPS coordinates</li>
            <li>Custom message text</li>
          </ul>

          <h3>Timing and Frequency</h3>
          <ul>
            <li>
              <strong>Immediate alerts:</strong> Sent as soon as the event occurs
            </li>
            <li>
              <strong>Delayed alerts:</strong> Wait for a specified time before sending
            </li>
            <li>
              <strong>Digest alerts:</strong> Combine multiple events into a single notification
            </li>
            <li>
              <strong>Quiet hours:</strong> Suppress alerts during specified time periods
            </li>
          </ul>

          <h2>Managing Alert Recipients</h2>

          <h3>User Groups</h3>
          <p>Create user groups for easier management:</p>
          <ol>
            <li>Go to User Management</li>
            <li>Create groups like "Dispatchers", "Managers", "Emergency Contacts"</li>
            <li>Assign users to appropriate groups</li>
            <li>Configure alerts to be sent to entire groups</li>
          </ol>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
