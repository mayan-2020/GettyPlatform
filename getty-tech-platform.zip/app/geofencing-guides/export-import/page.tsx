import { ArrowLeft, Download } from "lucide-react"

export default function ExportImportGeofences() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/geofencing-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Geofencing Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Download className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Export-Import Geofences</h1>
          <p className="text-lg text-slate-600">
            Transfer geofences between systems or create backups using export and import functionality.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Overview</h2>
          <p>
            The export-import feature allows you to backup your geofences, transfer them between different systems, or
            share geofence configurations with other users. This is essential for system migrations, backups, and
            collaborative fleet management.
          </p>

          <h2>Exporting Geofences</h2>

          <h3>Export Options</h3>
          <ul>
            <li>
              <strong>All Geofences:</strong> Export your entire geofence library
            </li>
            <li>
              <strong>Selected Geofences:</strong> Export only specific geofences
            </li>
            <li>
              <strong>By Category:</strong> Export geofences grouped by type or category
            </li>
          </ul>

          <h3>Export Formats</h3>
          <ul>
            <li>
              <strong>KML:</strong> Standard format compatible with Google Earth and other mapping tools
            </li>
            <li>
              <strong>CSV:</strong> Spreadsheet format for easy editing and data manipulation
            </li>
          </ul>

          <h3>Step-by-Step Export Process</h3>
          <ol>
            <li>Navigate to the Geofence Management section</li>
            <li>Click on "Export Geofences" button</li>
            <li>
              Select the geofences you want to export:
              <ul>
                <li>Use checkboxes to select individual geofences</li>
                <li>Use "Select All" for complete export</li>
                <li>Use filters to narrow down selection</li>
              </ul>
            </li>
            <li>Choose your preferred export format</li>
            <li>Click "Export" to generate the file</li>
            <li>Download the exported file to your computer</li>
          </ol>

          <h2>Import Process</h2>

          <h3>Preparing for Import</h3>
          <p>Before importing geofences:</p>
          <ul>
            <li>Verify file format compatibility</li>
            <li>Review geofence names for duplicates</li>
            <li>Backup existing geofences if needed</li>
          </ul>

          <h3>Import Steps</h3>
          <ol>
            <li>Go to Geofence Management</li>
            <li>Click "Import Geofences"</li>
            <li>Select your import file</li>
            <li>
              Handle duplicate names:
              <ul>
                <li>Skip duplicates</li>
                <li>Rename automatically</li>
                <li>Overwrite existing</li>
              </ul>
            </li>
            <li>Preview the import to verify data</li>
            <li>Execute the import</li>
            <li>Review import results and any errors</li>
          </ol>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
