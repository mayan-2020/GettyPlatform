import { ArrowLeft, Route } from "lucide-react"

export default function RouteGeofences() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/geofencing-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Geofencing Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Route className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">How to use route geofences</h1>
          <p className="text-lg text-slate-600">
            Create geofences along specific routes for enhanced tracking and ensure vehicles stay on designated paths.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Understanding Route Geofences</h2>
          <p>
            Route geofences are specialized virtual boundaries that follow a specific path or corridor. Unlike
            traditional circular or polygon geofences, route geofences create a buffer zone around a predetermined
            route, allowing you to monitor whether vehicles are staying on their assigned paths.
          </p>

          <h3>Benefits of Route Geofences</h3>
          <ul>
            <li>Ensure drivers follow designated routes</li>
            <li>Monitor route compliance and deviations</li>
            <li>Optimize delivery and service routes</li>
            <li>Improve safety by keeping vehicles on approved roads</li>
            <li>Reduce fuel costs by preventing unnecessary detours</li>
          </ul>

          <h2>Creating Route Geofences</h2>

          <h3>Step 1: Plan Your Route</h3>
          <ol>
            <li>Navigate to the Route Geofence creation tool</li>
            <li>Enter the starting point address or coordinates</li>
            <li>Add waypoints along the desired route</li>
          </ol>

          <h3>Step 2: Set Route Parameters</h3>
          <ul>
            <li>
              <strong>Buffer Width:</strong> Set the corridor width (typically 50-200 meters)
            </li>
            <li>
              <strong>Route Name:</strong> Give your route a descriptive name
            </li>
          </ul>

          <h3>Step 3: Configure Route Settings</h3>
          <ul>
            <li>
              <strong>Active Times:</strong> Set when the route geofence is active
            </li>
            <li>
              <strong>Vehicle Assignment:</strong> Select which vehicles use this route
            </li>
            <li>
              <strong>Tolerance Settings:</strong> Define acceptable deviation parameters
            </li>
            <li>
              <strong>Alert Preferences:</strong> Configure notifications for route violations
            </li>
          </ul>

          <h2>Route Monitoring and Alerts</h2>

          <h3>Route Deviation Alerts</h3>
          <p>Set up alerts for when vehicles deviate from assigned routes:</p>
          <ul>
            <li>
              <strong>Minor Deviation:</strong> Vehicle briefly leaves the route corridor
            </li>
            <li>
              <strong>Major Deviation:</strong> Vehicle significantly deviates from the planned path
            </li>
            <li>
              <strong>Route Abandonment:</strong> Vehicle completely leaves the designated route
            </li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
