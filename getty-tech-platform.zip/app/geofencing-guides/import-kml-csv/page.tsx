import { ArrowLeft, Upload } from "lucide-react"

export default function ImportKMLCSV() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/geofencing-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Geofencing Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Upload className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Import geofences in KML or CSV format</h1>
          <p className="text-lg text-slate-600">
            Bulk import geofences using standard file formats to quickly set up multiple virtual boundaries.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Supported File Formats</h2>
          <p>
            The system supports importing geofences from two main file formats: KML (Keyhole Markup Language) and CSV
            (Comma-Separated Values). Each format has its own advantages and use cases.
          </p>

          <h3>KML Format</h3>
          <ul>
            <li>Supports complex polygon shapes</li>
            <li>Includes geographic coordinate data</li>
            <li>Can contain multiple geofences in a single file</li>
            <li>Compatible with Google Earth and other mapping applications</li>
            <li>Preserves styling and description information</li>
          </ul>

          <h3>CSV Format</h3>
          <ul>
            <li>Simple text-based format</li>
            <li>Easy to create and edit in spreadsheet applications</li>
            <li>Ideal for circular geofences</li>
            <li>Supports bulk data entry</li>
            <li>Can be generated from existing databases</li>
          </ul>

          <h2>Preparing Your KML File</h2>

          <h3>KML File Structure</h3>
          <p>Your KML file should follow this basic structure:</p>
          <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto">
            {`<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <Placemark>
      <name>Geofence Name</name>
      <description>Geofence Description</description>
      <Polygon>
        <outerBoundaryIs>
          <LinearRing>
            <coordinates>
              -122.366,37.816,0
              -122.365,37.816,0
              -122.365,37.815,0
              -122.366,37.815,0
              -122.366,37.816,0
            </coordinates>
          </LinearRing>
        </outerBoundaryIs>
      </Polygon>
    </Placemark>
  </Document>
</kml>`}
          </pre>

          <h3>KML Requirements</h3>
          <ul>
            <li>Each geofence must be contained within a &lt;Placemark&gt; element</li>
            <li>Coordinates must be in longitude,latitude,altitude format</li>
            <li>Polygons must be closed (first and last coordinates must be identical)</li>
            <li>Maximum of 100 geofences per file</li>
            <li>File size limit: 10MB</li>
          </ul>

          <h2>Preparing Your CSV File</h2>

          <h3>CSV Format Requirements</h3>
          <p>Your CSV file should include the following columns:</p>
          <table className="min-w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-300 px-4 py-2">Column</th>
                <th className="border border-gray-300 px-4 py-2">Required</th>
                <th className="border border-gray-300 px-4 py-2">Description</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-2">name</td>
                <td className="border border-gray-300 px-4 py-2">Yes</td>
                <td className="border border-gray-300 px-4 py-2">Geofence name</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">latitude</td>
                <td className="border border-gray-300 px-4 py-2">Yes</td>
                <td className="border border-gray-300 px-4 py-2">Center latitude</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">longitude</td>
                <td className="border border-gray-300 px-4 py-2">Yes</td>
                <td className="border border-gray-300 px-4 py-2">Center longitude</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">radius</td>
                <td className="border border-gray-300 px-4 py-2">Yes</td>
                <td className="border border-gray-300 px-4 py-2">Radius in meters</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">description</td>
                <td className="border border-gray-300 px-4 py-2">No</td>
                <td className="border border-gray-300 px-4 py-2">Geofence description</td>
              </tr>
            </tbody>
          </table>

          <h3>CSV Example</h3>
          <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto">
            {`name,latitude,longitude,radius,description
"Warehouse A",40.7128,-74.0060,500,"Main distribution center"
"Customer Site 1",40.7589,-73.9851,200,"Delivery location"
"Service Center",40.6892,-74.0445,300,"Vehicle maintenance facility"`}
          </pre>

          <h2>Import Process</h2>

          <h3>Step-by-Step Import</h3>
          <ol>
            <li>Navigate to the Geofence management section</li>
            <li>Click on "Import Geofences" or "Bulk Import"</li>
            <li>Select your file format (KML or CSV)</li>
            <li>Click "Choose File" and select your prepared file</li>
            <li>Review the import preview to verify data accuracy</li>
            <li>
              Configure import settings:
              <ul>
                <li>Overwrite existing geofences with same names</li>
                <li>Skip duplicate entries</li>
                <li>Set default alert settings for imported geofences</li>
              </ul>
            </li>
            <li>Click "Import" to process the file</li>
          </ol>

          <h3>Import Validation</h3>
          <p>The system will validate your file for:</p>
          <ul>
            <li>Correct file format and structure</li>
            <li>Valid coordinate ranges</li>
            <li>Required field completeness</li>
            <li>Duplicate geofence names</li>
            <li>File size and geofence count limits</li>
          </ul>

          <h2>Post-Import Configuration</h2>

          <h3>Review Imported Geofences</h3>
          <ol>
            <li>Check the import summary for any errors or warnings</li>
            <li>Review each imported geofence on the map</li>
            <li>Verify that boundaries are correctly positioned</li>
            <li>Confirm that names and descriptions are accurate</li>
          </ol>

          <h3>Configure Alert Settings</h3>
          <p>After import, you may need to:</p>
          <ul>
            <li>Set up email and SMS notifications</li>
            <li>Assign geofences to specific vehicle groups</li>
            <li>Configure entry and exit alert rules</li>
            <li>Set active time periods for each geofence</li>
          </ul>

          <h2>Troubleshooting Common Issues</h2>

          <h3>Import Errors</h3>
          <ul>
            <li>
              <strong>Invalid coordinates:</strong> Check that latitude/longitude values are within valid ranges
            </li>
            <li>
              <strong>File format errors:</strong> Ensure your file follows the correct structure
            </li>
            <li>
              <strong>Duplicate names:</strong> Use unique names for each geofence
            </li>
            <li>
              <strong>File too large:</strong> Split large files into smaller batches
            </li>
          </ul>

          <h3>Performance Tips</h3>
          <ul>
            <li>Import geofences in batches of 50 or fewer for optimal performance</li>
            <li>Use simple polygon shapes when possible</li>
            <li>Avoid overlapping geofences that might cause conflicts</li>
            <li>Test with a small sample file before importing large datasets</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
