import { ArrowLeft, Bell } from "lucide-react"

export default function EventRulesIntroduction() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/alerts-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Alerts Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Bell className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Event Rules Introduction</h1>
          <p className="text-lg text-slate-600">
            Learn the fundamentals of creating and managing event rules to automate your fleet monitoring and response
            systems.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>What are Event Rules?</h2>
          <p>
            Event rules are automated conditions that monitor your fleet's activities and trigger specific actions when
            certain criteria are met. They form the backbone of proactive fleet management, allowing you to respond to
            situations in real-time without constant manual monitoring.
          </p>

          <h3>Key Benefits</h3>
          <ul>
            <li>
              <strong>Proactive Monitoring:</strong> Automatically detect issues before they become problems
            </li>
            <li>
              <strong>Improved Safety:</strong> Instant alerts for speeding, harsh driving, or emergency situations
            </li>
            <li>
              <strong>Operational Efficiency:</strong> Automate routine monitoring tasks
            </li>
            <li>
              <strong>Cost Reduction:</strong> Reduce fuel costs and vehicle wear through behavior monitoring
            </li>
            <li>
              <strong>Compliance:</strong> Ensure adherence to company policies and regulations
            </li>
          </ul>

          <h2>Types of Event Rules</h2>

          <h3>1. Movement-Based Rules</h3>
          <ul>
            <li>
              <strong>Speeding:</strong> Alerts when vehicles exceed speed limits
            </li>
            <li>
              <strong>Harsh Acceleration/Braking:</strong> Monitors driving behavior
            </li>
            <li>
              <strong>Idle Time:</strong> Tracks excessive idling
            </li>
            <li>
              <strong>Route Deviation:</strong> Alerts when vehicles leave designated routes
            </li>
          </ul>

          <h3>2. Location-Based Rules</h3>
          <ul>
            <li>
              <strong>Geofence Entry/Exit:</strong> Monitors boundary crossings
            </li>
            <li>
              <strong>Unauthorized Area Access:</strong> Alerts for restricted zone entries
            </li>
            <li>
              <strong>Landmark Proximity:</strong> Notifications when near specific locations
            </li>
          </ul>

          <h3>3. Time-Based Rules</h3>
          <ul>
            <li>
              <strong>After-Hours Usage:</strong> Monitors vehicle use outside business hours
            </li>
            <li>
              <strong>Scheduled Maintenance:</strong> Reminders based on time or mileage
            </li>
            <li>
              <strong>Driver Hours:</strong> Compliance with work time regulations
            </li>
          </ul>

          <h3>4. Emergency Rules</h3>
          <ul>
            <li>
              <strong>Panic Button:</strong> Immediate response to SOS signals
            </li>
            <li>
              <strong>Vehicle Theft:</strong> Unauthorized movement alerts
            </li>
          </ul>

          <h2>Event Rule Components</h2>

          <h3>Triggers</h3>
          <p>Conditions that activate the rule:</p>
          <ul>
            <li>Speed thresholds</li>
            <li>Geographic boundaries</li>
            <li>Time periods</li>
            <li>Vehicle status changes</li>
            <li>Driver behavior patterns</li>
          </ul>

          <h3>Conditions</h3>
          <p>Additional criteria that must be met:</p>
          <ul>
            <li>Duration requirements</li>
            <li>Vehicle type filters</li>
            <li>Driver assignments</li>
            <li>Day/time restrictions</li>
          </ul>

          <h3>Actions</h3>
          <p>Responses when rules are triggered:</p>
          <ul>
            <li>Email notifications</li>
            <li>Push notifications</li>
            <li>Visual/audio alarms</li>
            <li>Report generation</li>
          </ul>

          <h2>Event Rule Lifecycle</h2>

          <h3>1. Planning Phase</h3>
          <ul>
            <li>Identify monitoring requirements</li>
            <li>Define success criteria</li>
            <li>Determine notification recipients</li>
            <li>Set priority levels</li>
          </ul>

          <h3>2. Configuration Phase</h3>
          <ul>
            <li>Create rule conditions</li>
            <li>Set up notification methods</li>
            <li>Test with sample data</li>
            <li>Assign to vehicle groups</li>
          </ul>

          <h3>3. Deployment Phase</h3>
          <ul>
            <li>Activate rules gradually</li>
            <li>Monitor initial performance</li>
            <li>Adjust thresholds as needed</li>
            <li>Train staff on responses</li>
          </ul>

          <h3>4. Maintenance Phase</h3>
          <ul>
            <li>Regular performance reviews</li>
            <li>Update conditions as needed</li>
            <li>Archive obsolete rules</li>
            <li>Optimize notification frequency</li>
          </ul>

          <h2>Best Practices</h2>

          <h3>Rule Design</h3>
          <ul>
            <li>
              <strong>Start Simple:</strong> Begin with basic rules and add complexity gradually
            </li>
            <li>
              <strong>Be Specific:</strong> Use precise conditions to avoid false alerts
            </li>
            <li>
              <strong>Consider Context:</strong> Account for different scenarios and exceptions
            </li>
            <li>
              <strong>Test Thoroughly:</strong> Validate rules before full deployment
            </li>
          </ul>

          <h3>Notification Management</h3>
          <ul>
            <li>
              <strong>Right Person:</strong> Send alerts to appropriate personnel
            </li>
            <li>
              <strong>Right Time:</strong> Consider time zones and work schedules
            </li>
            <li>
              <strong>Right Method:</strong> Use appropriate communication channels
            </li>
            <li>
              <strong>Avoid Overload:</strong> Prevent alert fatigue with smart filtering
            </li>
          </ul>

          <h3>Performance Optimization</h3>
          <ul>
            <li>Monitor rule effectiveness regularly</li>
            <li>Adjust thresholds based on real-world data</li>
            <li>Remove or modify underperforming rules</li>
            <li>Balance sensitivity with practicality</li>
          </ul>

          <h2>Getting Started</h2>

          <h3>Step 1: Assessment</h3>
          <ol>
            <li>Identify your primary monitoring needs</li>
            <li>Prioritize based on safety and business impact</li>
            <li>Determine available resources for response</li>
          </ol>

          <h3>Step 2: Planning</h3>
          <ol>
            <li>Design your first set of basic rules</li>
            <li>Define notification workflows</li>
            <li>Prepare staff training materials</li>
          </ol>

          <h3>Step 3: Implementation</h3>
          <ol>
            <li>Start with a pilot group of vehicles</li>
            <li>Monitor and adjust initial settings</li>
            <li>Gradually expand to full fleet</li>
          </ol>

          <h2>Next Steps</h2>
          <p>Now that you understand the basics of event rules, you can explore specific implementation guides:</p>
          <ul>
            <li>Use the Custom Event Rules Wizard for step-by-step creation</li>
            <li>Learn about the Event Panel for monitoring and management</li>
            <li>Explore specific use cases like speeding alerts and SOS notifications</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
