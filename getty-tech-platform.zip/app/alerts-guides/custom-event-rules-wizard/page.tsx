import { ArrowLeft, Wand2 } from "lucide-react"

export default function CustomEventRulesWizard() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/alerts-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Alerts Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Wand2 className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Custom Event Rules Wizard: A Step-by-Step Guide</h1>
          <p className="text-lg text-slate-600">
            Use the intuitive wizard interface to create custom event rules with ease, no technical expertise required.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Overview of the Event Rules Wizard</h2>
          <p>
            The Custom Event Rules Wizard is a user-friendly interface that guides you through creating sophisticated
            event rules without requiring technical knowledge. The wizard breaks down the complex process into simple,
            manageable steps.
          </p>

          <h3>Wizard Benefits</h3>
          <ul>
            <li>
              <strong>Guided Process:</strong> Step-by-step instructions with helpful tips
            </li>
            <li>
              <strong>Visual Interface:</strong> Intuitive forms and dropdown menus
            </li>
            <li>
              <strong>Validation:</strong> Real-time error checking and suggestions
            </li>
            <li>
              <strong>Preview:</strong> See how your rule will work before activation
            </li>
            <li>
              <strong>Templates:</strong> Pre-built templates for common scenarios
            </li>
          </ul>

          <h2>Accessing the Wizard</h2>

          <h3>Navigation Steps</h3>
          <ol>
            <li>Log into your fleet management dashboard</li>
            <li>Navigate to the "Alerts" or "Event Rules" section</li>
            <li>Click "Create New Rule" or "Add Event Rule"</li>
            <li>Select "Use Wizard" option</li>
            <li>Choose "Custom Rule" from the template options</li>
          </ol>

          <h2>Step 1: Rule Basic Information</h2>

          <h3>Required Fields</h3>
          <ul>
            <li>
              <strong>Rule Name:</strong> Descriptive name for easy identification
              <ul>
                <li>Example: "Downtown Speeding Alert"</li>
                <li>Keep it concise but descriptive</li>
                <li>Use consistent naming conventions</li>
              </ul>
            </li>
            <li>
              <strong>Description:</strong> Detailed explanation of the rule's purpose
              <ul>
                <li>Include trigger conditions</li>
                <li>Mention expected actions</li>
                <li>Note any special considerations</li>
              </ul>
            </li>
          </ul>

          <h2>Step 2: Define Trigger Conditions</h2>

          <h3>Primary Trigger Selection</h3>
          <p>Choose the main condition that will activate your rule:</p>

          <h4>Speed-Based Triggers</h4>
          <ul>
            <li>
              <strong>Speed Limit Exceeded:</strong> Vehicle exceeds posted speed limit
            </li>
            <li>
              <strong>Custom Speed Threshold:</strong> Vehicle exceeds your defined speed
            </li>
            <li>
              <strong>Speed Zone Violation:</strong> Speeding in specific areas
            </li>
          </ul>

          <h4>Location-Based Triggers</h4>
          <ul>
            <li>
              <strong>Geofence Entry:</strong> Vehicle enters defined area
            </li>
            <li>
              <strong>Geofence Exit:</strong> Vehicle leaves defined area
            </li>
            <li>
              <strong>Proximity Alert:</strong> Vehicle approaches specific location
            </li>
          </ul>

          <h4>Time-Based Triggers</h4>
          <ul>
            <li>
              <strong>After Hours Operation:</strong> Vehicle use outside business hours
            </li>
            <li>
              <strong>Extended Idle:</strong> Vehicle idle for specified duration
            </li>
            <li>
              <strong>Scheduled Events:</strong> Time-based reminders
            </li>
          </ul>

          <h3>Setting Trigger Parameters</h3>

          <h4>For Speed Triggers</h4>
          <ul>
            <li>
              <strong>Speed Threshold:</strong> Set the speed limit (e.g., 65 mph)
            </li>
            <li>
              <strong>Duration:</strong> How long speeding must occur (e.g., 30 seconds)
            </li>
          </ul>

          <h4>For Location Triggers</h4>
          <ul>
            <li>
              <strong>Geofence Selection:</strong> Choose from existing geofences
            </li>
            <li>
              <strong>Direction:</strong> Entry, exit, or both
            </li>
          </ul>

          <h2>Step 3: Add Conditions and Filters</h2>

          <h3>Vehicle Filters</h3>
          <ul>
            <li>
              <strong>Specific Vehicles:</strong> Select individual vehicles
            </li>
            <li>
              <strong>Vehicle Groups:</strong> Apply to entire fleets or departments
            </li>
            <li>
              <strong>Vehicle Types:</strong> Filter by truck, van, car, etc.
            </li>
          </ul>

          <h3>Time Filters</h3>
          <ul>
            <li>
              <strong>Business Hours:</strong> Only during work hours
            </li>
            <li>
              <strong>Specific Days:</strong> Weekdays, weekends, or custom
            </li>
            <li>
              <strong>Date Ranges:</strong> Temporary rules for specific periods
            </li>
          </ul>

          <h3>Driver Filters</h3>
          <ul>
            <li>
              <strong>Specific Drivers:</strong> Target individual drivers
            </li>
            <li>
              <strong>Driver Groups:</strong> New drivers, contractors, etc.
            </li>
            <li>
              <strong>License Types:</strong> CDL, regular license, etc.
            </li>
          </ul>

          <h2>Step 4: Configure Actions and Notifications</h2>

          <h3>Notification Methods</h3>

          <h4>Email Notifications</h4>
          <ul>
            <li>
              <strong>Recipients:</strong> Add email addresses
            </li>
            <li>
              <strong>Subject Line:</strong> Customize email subject
            </li>
            <li>
              <strong>Message Template:</strong> Include relevant details
            </li>
            <li>
              <strong>Attachments:</strong> Include maps or reports
            </li>
          </ul>

          <h4>Push Notifications</h4>
          <ul>
            <li>
              <strong>Mobile App Users:</strong> Select app users
            </li>
            <li>
              <strong>Notification Priority:</strong> High, normal, or low
            </li>
            <li>
              <strong>Sound Alerts:</strong> Custom notification sounds
            </li>
          </ul>

          <h3>Additional Actions</h3>
          <ul>
            <li>
              <strong>Dashboard Alerts:</strong> Visual indicators on main screen
            </li>
            <li>
              <strong>Report Generation:</strong> Automatic report creation
            </li>
            <li>
              <strong>Vehicle Commands:</strong> Remote actions (if supported)
            </li>
          </ul>

          <h2>Step 6: Review and Test</h2>

          <h3>Rule Summary Review</h3>
          <ul>
            <li>Verify all trigger conditions</li>
            <li>Check notification recipients</li>
            <li>Confirm vehicle assignments</li>
            <li>Review time and date filters</li>
          </ul>

          <h3>Testing Options</h3>
          <ul>
            <li>
              <strong>Simulation Mode:</strong> Test with historical data
            </li>
            <li>
              <strong>Test Notifications:</strong> Send sample alerts
            </li>
            <li>
              <strong>Pilot Deployment:</strong> Test with limited vehicles
            </li>
          </ul>

          <h2>Step 7: Deployment and Activation</h2>

          <h3>Deployment Strategies</h3>
          <ul>
            <li>
              <strong>Immediate Activation:</strong> Rule goes live immediately
            </li>
            <li>
              <strong>Scheduled Activation:</strong> Set future start date
            </li>
            <li>
              <strong>Gradual Rollout:</strong> Phase in across vehicle groups
            </li>
          </ul>

          <h3>Monitoring Initial Performance</h3>
          <ul>
            <li>Watch for false positives</li>
            <li>Monitor alert frequency</li>
            <li>Gather feedback from recipients</li>
            <li>Adjust thresholds as needed</li>
          </ul>

          <h2>Common Wizard Templates</h2>

          <h3>Speed Monitoring Template</h3>
          <ul>
            <li>Pre-configured speed thresholds</li>
            <li>Standard notification templates</li>
            <li>Common escalation rules</li>
          </ul>

          <h3>Geofence Alert Template</h3>
          <ul>
            <li>Entry/exit notification setup</li>
            <li>Customer notification options</li>
            <li>Time-based filtering</li>
          </ul>

          <h3>Emergency Response Template</h3>
          <ul>
            <li>High-priority alert settings</li>
            <li>Multiple notification methods</li>
            <li>Immediate escalation rules</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
