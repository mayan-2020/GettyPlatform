import { ArrowLeft, AlertTriangle } from "lucide-react"

export default function SMSSOSEvents() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/alerts-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Alerts Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>
      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-red-100 text-red-600 mb-6">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">
            Event Rule Use Case: Send Alerts when SOS Event Occurs
          </h1>
          <p className="text-lg text-slate-600">
            Configure emergency notifications for SOS situations to ensure rapid response to critical incidents.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Understanding SOS Events</h2>
          <p>
            SOS (Save Our Souls) events are emergency signals triggered by drivers or automatically by the system when
            critical situations are detected. These events require immediate attention and rapid response protocols.
          </p>

          <h3>Types of SOS Events</h3>
          <ul>
            <li>
              <strong>Manual SOS:</strong> Driver-activated panic button
            </li>
            <li>
              <strong>Automatic Crash Detection:</strong> System-detected accidents
            </li>
            <li>
              <strong>Medical Emergency:</strong> Health-related emergency signals
            </li>
            <li>
              <strong>Security Threat:</strong> Duress or security-related alerts
            </li>
            <li>
              <strong>Vehicle Breakdown:</strong> Critical mechanical failures
            </li>
          </ul>

          <h2>Setting Up SOS Email Alerts</h2>

          <h3>Step 1: Create the SOS Event Rule</h3>
          <ol>
            <li>Navigate to Event Rules → Create New Rule</li>
            <li>Select "Emergency/SOS" category</li>
            <li>Choose "SOS Button Pressed" or "Emergency Signal" trigger</li>
            <li>Set rule name: "SOS Emergency Notification Alert"</li>
            <li>Set priority to "Critical" or "Emergency"</li>
          </ol>

          <h3>Step 2: Configure Trigger Conditions</h3>

          <h4>SOS Signal Detection</h4>
          <ul>
            <li>
              <strong>Manual SOS:</strong> Physical button press or app activation
              <ul>
                <li>Single press vs. double press options</li>
                <li>Hold duration requirements</li>
                <li>Confirmation prompts</li>
              </ul>
            </li>
            <li>
              <strong>Automatic SOS:</strong> System-generated emergencies
              <ul>
                <li>Crash detection algorithms</li>
                <li>Sudden stop detection</li>
                <li>Airbag deployment signals</li>
              </ul>
            </li>
          </ul>

          <h4>Validation Settings</h4>
          <ul>
            <li>
              <strong>Confirmation Period:</strong> Time to cancel false alarms (30-60 seconds)
            </li>
            <li>
              <strong>Escalation Delay:</strong> Time before full emergency response
            </li>
            <li>
              <strong>Auto-Cancel:</strong> Conditions that automatically cancel alerts
            </li>
          </ul>

          <h3>Step 3: Configure Email Notifications</h3>

          <h4>Primary Notification Recipients</h4>
          <ul>
            <li>
              <strong>Emergency Contacts:</strong>
              <ul>
                <li>Fleet manager (primary)</li>
                <li>Safety director</li>
                <li>On-call supervisor</li>
                <li>Security personnel</li>
              </ul>
            </li>
            <li>
              <strong>External Contacts:</strong>
              <ul>
                <li>Emergency services (if authorized)</li>
                <li>Company security</li>
                <li>Driver's emergency contact</li>
              </ul>
            </li>
          </ul>

          <h4>Email Message Configuration</h4>
          <ul>
            <li>
              <strong>Message Template:</strong>
              <pre className="bg-gray-100 p-4 rounded-lg">
                {`🚨 EMERGENCY SOS ALERT 🚨
Vehicle: [VEHICLE_NAME]
Driver: [DRIVER_NAME]
Location: [ADDRESS]
Time: [TIMESTAMP]
GPS: [COORDINATES]
Respond immediately!`}
              </pre>
            </li>
            <li>
              <strong>Message Elements:</strong>
              <ul>
                <li>Clear emergency indicator</li>
                <li>Vehicle and driver identification</li>
                <li>Precise location information</li>
                <li>Timestamp of event</li>
                <li>GPS coordinates for navigation</li>
                <li>Clear call to action</li>
              </ul>
            </li>
          </ul>

          <h2>Advanced SOS Configuration</h2>

          <h3>Escalation Procedures</h3>

          <h4>Immediate Response (0-2 minutes)</h4>
          <ul>
            <li>Email to primary emergency contacts</li>
            <li>Push notifications to mobile apps</li>
            <li>Dashboard alert with audio alarm</li>
            <li>Attempt to contact driver via radio/phone</li>
          </ul>

          <h4>Secondary Response (2-5 minutes)</h4>
          <ul>
            <li>Email to secondary contacts if no acknowledgment</li>
            <li>Email with detailed incident report</li>
            <li>Automatic incident case creation</li>
            <li>Dispatch nearest available personnel</li>
          </ul>

          <h4>Final Escalation (5+ minutes)</h4>
          <ul>
            <li>Contact emergency services (911)</li>
            <li>Notify senior management</li>
            <li>Activate full emergency response protocol</li>
            <li>Begin incident documentation</li>
          </ul>

          <h3>Location-Based Enhancements</h3>

          <h4>Automatic Location Services</h4>
          <ul>
            <li>
              <strong>Reverse Geocoding:</strong> Convert GPS to street address
            </li>
            <li>
              <strong>Landmark Identification:</strong> Nearest recognizable locations
            </li>
            <li>
              <strong>Emergency Services Lookup:</strong> Closest hospitals, police, fire
            </li>
            <li>
              <strong>Route Guidance:</strong> Directions to incident location
            </li>
          </ul>

          <h4>Enhanced Location Data</h4>
          <ul>
            <li>GPS coordinates with accuracy indicators</li>
            <li>What3Words location codes</li>
            <li>Plus codes for remote areas</li>
            <li>Nearest mile markers or exit numbers</li>
          </ul>

          <h2>Integration with Emergency Services</h2>

          <h3>Direct Emergency Service Integration</h3>
          <ul>
            <li>
              <strong>911 Integration:</strong> Automatic emergency service notification
              <ul>
                <li>Requires special authorization</li>
                <li>Must comply with local regulations</li>
                <li>Include callback number</li>
              </ul>
            </li>
            <li>
              <strong>Private Security:</strong> Company security service alerts
              <ul>
                <li>Direct communication channels</li>
                <li>Incident escalation protocols</li>
                <li>Response coordination</li>
              </ul>
            </li>
          </ul>

          <h3>Medical Emergency Features</h3>
          <ul>
            <li>
              <strong>Medical Information:</strong> Driver medical conditions/allergies
            </li>
            <li>
              <strong>Emergency Contacts:</strong> Family/personal emergency contacts
            </li>
            <li>
              <strong>Insurance Information:</strong> Medical insurance details
            </li>
            <li>
              <strong>Hospital Preferences:</strong> Preferred medical facilities
            </li>
          </ul>

          <h2>False Alarm Prevention</h2>

          <h3>Confirmation Mechanisms</h3>
          <ul>
            <li>
              <strong>Driver Confirmation:</strong>
              <ul>
                <li>Voice confirmation via hands-free system</li>
                <li>Mobile app confirmation</li>
                <li>Secondary button press</li>
              </ul>
            </li>
            <li>
              <strong>Automatic Validation:</strong>
              <ul>
                <li>Movement detection after alert</li>
                <li>Normal driving pattern resumption</li>
                <li>Radio communication response</li>
              </ul>
            </li>
          </ul>

          <h3>False Alarm Handling</h3>
          <ul>
            <li>
              <strong>Cancellation Window:</strong> 30-60 second window to cancel
            </li>
            <li>
              <strong>Verification Calls:</strong> Attempt to contact driver first
            </li>
            <li>
              <strong>Graduated Response:</strong> Increase response based on confirmation
            </li>
            <li>
              <strong>Learning System:</strong> Adjust sensitivity based on false alarm patterns
            </li>
          </ul>

          <h2>Testing and Maintenance</h2>

          <h3>Regular Testing Procedures</h3>
          <ul>
            <li>
              <strong>Monthly SOS Tests:</strong>
              <ul>
                <li>Test SOS button functionality</li>
                <li>Verify notification delivery</li>
                <li>Check response times</li>
                <li>Update contact information</li>
              </ul>
            </li>
            <li>
              <strong>Quarterly Drills:</strong>
              <ul>
                <li>Full emergency response simulation</li>
                <li>Staff response training</li>
                <li>Communication system testing</li>
                <li>Procedure review and updates</li>
              </ul>
            </li>
          </ul>

          <h3>System Maintenance</h3>
          <ul>
            <li>
              <strong>Contact List Updates:</strong> Regular review of emergency contacts
            </li>
            <li>
              <strong>Device Testing:</strong> SOS button and communication device checks
            </li>
            <li>
              <strong>Network Reliability:</strong> Cellular and communication network testing
            </li>
            <li>
              <strong>Battery Backup:</strong> Emergency power system verification
            </li>
          </ul>

          <h2>Compliance and Legal Considerations</h2>

          <h3>Regulatory Requirements</h3>
          <ul>
            <li>
              <strong>DOT Regulations:</strong> Commercial vehicle emergency requirements
            </li>
            <li>
              <strong>OSHA Standards:</strong> Workplace safety emergency procedures
            </li>
            <li>
              <strong>State Laws:</strong> Emergency notification requirements
            </li>
            <li>
              <strong>Industry Standards:</strong> Sector-specific emergency protocols
            </li>
          </ul>

          <h3>Documentation Requirements</h3>
          <ul>
            <li>
              <strong>Incident Reports:</strong> Detailed documentation of all SOS events
            </li>
            <li>
              <strong>Response Times:</strong> Track and report emergency response metrics
            </li>
            <li>
              <strong>Training Records:</strong> Staff emergency response training documentation
            </li>
            <li>
              <strong>System Logs:</strong> Technical logs of SOS system performance
            </li>
          </ul>

          <h2>Best Practices</h2>

          <h3>Implementation</h3>
          <ul>
            <li>
              <strong>Start with Pilot Program:</strong> Test with limited vehicles first
            </li>
            <li>
              <strong>Train All Personnel:</strong> Ensure everyone knows their role
            </li>
            <li>
              <strong>Clear Procedures:</strong> Document step-by-step response protocols
            </li>
            <li>
              <strong>Regular Updates:</strong> Keep contact information current
            </li>
          </ul>

          <h3>Response Optimization</h3>
          <ul>
            <li>
              <strong>Response Time Goals:</strong> Set and monitor response time targets
            </li>
            <li>
              <strong>Resource Allocation:</strong> Ensure adequate response resources
            </li>
            <li>
              <strong>Communication Clarity:</strong> Use clear, concise emergency communications
            </li>
            <li>
              <strong>Follow-up Procedures:</strong> Ensure proper incident closure
            </li>
          </ul>

          <h3>Continuous Improvement</h3>
          <ul>
            <li>Regular review of SOS events and responses</li>
            <li>Feedback collection from drivers and responders</li>
            <li>Technology updates and improvements</li>
            <li>Benchmarking against industry standards</li>
          </ul>
        </div>
      </main>
      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
      \
    </div>
  )
}
