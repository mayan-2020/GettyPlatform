import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Copy, Settings, ArrowLeft } from "lucide-react"
import Image from "next/image"

export default function CloneEventRulesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Platform
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Copy className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">How to clone event rules</h1>
          <p className="text-lg text-slate-600">
            In some circumstances, you might want to clone an event rule. This lets you reuse part of the content of an
            existing rule to quickly create a new one - saving you time in the process.
          </p>
        </div>

        <Card className="mb-8 shadow-lg">
          <CardHeader className="bg-slate-50">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Settings className="h-6 w-6 text-blue-600" />
              Cloning event rules
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <Badge
                  variant="outline"
                  className="w-8 h-8 rounded-full p-0 flex items-center justify-center bg-blue-100 text-blue-700 border-blue-300"
                >
                  1
                </Badge>
                <span className="text-slate-700 text-base">Log in to your application</span>
              </div>

              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <Badge
                  variant="outline"
                  className="w-8 h-8 rounded-full p-0 flex items-center justify-center bg-blue-100 text-blue-700 border-blue-300"
                >
                  2
                </Badge>
                <span className="text-slate-700 text-base">
                  Go to Main Menu {">"} Admin {">"} Event Rules
                </span>
              </div>

              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <Badge
                  variant="outline"
                  className="w-8 h-8 rounded-full p-0 flex items-center justify-center bg-blue-100 text-blue-700 border-blue-300"
                >
                  3
                </Badge>
                <span className="text-slate-700 text-base">Right-click on the rule you want to duplicate.</span>
              </div>

              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <Badge
                  variant="outline"
                  className="w-8 h-8 rounded-full p-0 flex items-center justify-center bg-blue-100 text-blue-700 border-blue-300"
                >
                  4
                </Badge>
                <span className="text-slate-700 text-base">Select the option Clone</span>
              </div>

              <div className="my-8">
                <div className="border rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/clone-event-rule.png"
                    alt="Event rules list with clone option highlighted"
                    width={800}
                    height={500}
                    className="w-full"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <Badge
                  variant="outline"
                  className="w-8 h-8 rounded-full p-0 flex items-center justify-center bg-blue-100 text-blue-700 border-blue-300"
                >
                  5
                </Badge>
                <span className="text-slate-700 text-base">Now make the relevant changes to your new rule.</span>
              </div>

              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <Badge
                  variant="outline"
                  className="w-8 h-8 rounded-full p-0 flex items-center justify-center bg-blue-100 text-blue-700 border-blue-300"
                >
                  6
                </Badge>
                <span className="text-slate-700 text-base">Save your new rule.</span>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mt-8">
              <h4 className="font-semibold text-blue-800 mb-2 text-lg">
                When else might you want to clone an event rule?
              </h4>
              <p className="text-blue-700 text-base">
                You might use separate event rules to differentiate notifications or reports.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
