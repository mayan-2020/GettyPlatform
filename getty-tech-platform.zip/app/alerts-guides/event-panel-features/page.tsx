import { ArrowLeft, Activity } from "lucide-react"

export default function EventPanelFeatures() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/alerts-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Alerts Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Activity className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Event Panel Features & Management</h1>
          <p className="text-lg text-slate-600 mb-8">
            The event panel design helps customers manage events quickly and accurately. All of the features have been
            designed with operators and managers in mind. Read on to learn how to use and enable the new features.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Real-Time Overview</h2>
          <p>
            The Real-Time Overview feature provides immediate visibility into ongoing events. Events are displayed in
            two formats: card view and list view. Key rules include:
          </p>

          <p>
            <strong>Display Format:</strong> Users can choose between a card view or a list view for monitoring events.
          </p>

          <p>
            <strong>Event Color Coding:</strong>
          </p>
          <ul>
            <li>Events shown in black represent all open events.</li>
            <li>Events shown in red indicate newly opened events.</li>
          </ul>

          <p>
            <strong>Event Count:</strong> Each event card or list item shows the total number of open events.
          </p>

          <h3>Card overview</h3>
          <p>
            All active event rules show in a card carousel. You know exactly what's going on with your fleet at all
            times. You can see the total open events on the card. New/unseen event counts are shown in the red circles.
          </p>

          <p>You can see the current count for each event type on the card and the number of new events.</p>

          <div className="my-8">
            <img
              src="/images/event-panel-card-view.png"
              alt="Event Panel Card View"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <h3>List overview</h3>
          <p>
            If you want to see a list view in the events panel, click the list icon to change the view. You can monitor
            events as they occur in real time.
          </p>

          <div className="my-8">
            <img
              src="/images/event-panel-list-view.png"
              alt="Event Panel List View"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <h3>Event location on the map:</h3>
          <p>
            You can also view real-time event information by checking the open event counts directly on the asset
            markers displayed on the map.
          </p>

          <div className="my-8">
            <img
              src="/images/event-panel-overview.png"
              alt="Event Panel Overview"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <div className="my-8">
            <img
              src="/images/event-location-map.png"
              alt="Event Location on Map"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <h3>Open events in the Asset List:</h3>
          <p>
            You can also choose to display an open events column in the Asset List. To do this, right-click on any
            column to edit the columns shown. Click on a column header (e.g. Open events) to sort the assets by this
            column.
          </p>

          <div className="my-8">
            <img
              src="/images/asset-list-open-events.png"
              alt="Asset List Open Events"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <h2>Events drill-down</h2>
          <p>It's easy to drill down to the information that matters to you - events by type, date, or asset.</p>

          <p>
            To drill down to today's open events for an event type, simply click on the list icon directly on the event
            card. This will display all open events from today's date. To change the event data columns displayed in
            this view, right-click on a column.
          </p>

          <div className="my-8">
            <img
              src="/images/event-card-drill-down.png"
              alt="Event Card Drill Down"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <div className="my-8">
            <img
              src="/images/event-drill-down-details.png"
              alt="Event Drill Down Details"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <p>You can also add a filter on event type or event date from the main list overview.</p>

          <p>To filter by event type, click the Filter Events button.</p>

          <div className="my-8">
            <img
              src="/images/event-panel-filtered-list.png"
              alt="Event Panel Filtered List"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <p>
            To filter by event date, click the Filter by time and date... If you select a date in the past, you will see
            open & closed events from that date.
          </p>

          <p>
            You can also click on any asset on the map to drill down. Right-click on the user and select 'Show only
            this.' All open events will show for the asset.
          </p>

          <div className="my-8">
            <img src="/images/map-context-menu.png" alt="Map Context Menu" className="w-full rounded-lg shadow-md" />
          </div>

          <p>Remember, you can edit the columns to see additional event fields in this view.</p>

          <p>Events are tied directly to assets so operators know immediately which driver to call.</p>

          <h2>Prioritized notifications</h2>
          <p>
            Operators need to know immediately about serious events. The pop-up notifications provide real-time
            information on high-priority events like SOS or speeding.
          </p>

          <div className="my-8">
            <img
              src="/images/event-notification-popup.png"
              alt="Event Notification Popup"
              className="w-full rounded-lg shadow-md"
            />
          </div>

          <h3>High-priority events</h3>
          <p>To enable pop-up notifications for high-priority events, click on the menu icon in the events panel.</p>

          <p>Press on Edit notification settings...</p>

          <p>
            Select an event rule to enable/disable notifications. Be sure to save the workspace after saving your
            changes.
          </p>

          <p>
            Operators can monitor lower-priority events in the real-time overview. The new event count on the cards
            alerts them to new incidents, or they can see them in the list view.
          </p>

          <h2>Detailed event records</h2>
          <p>
            Each event record contains key information from the asset outputs. Operators can also record notes when
            closing an event.
          </p>

          <p>
            To close an event and add comments, click on the event, and select 'close event.' Type in operator notes
            before closing the event.
          </p>

          <p>
            Detailed event records let managers know exactly what happened in the field and in the office. Event records
            help form an audit trail and make events traceable back to drivers and operators. You can be sure that
            official processes and protocols are followed.
          </p>

          <p>
            The event record will contain the date, time, location, and asset. It may also have other event-specific
            information such as speed, temperature, idling time, etc. In addition, it will have any operator comments.
          </p>

          <h2>Deprecated features</h2>
          <p>Former Timeline and Event Icons are replaced by Area Search.</p>

          <h2>Additional Tips</h2>
          <p>As always, be sure to save your configured workspace to be sure you don't lose edits and changes.</p>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
