import { ArrowLeft, Gauge } from "lucide-react"

export default function CatchSpeedingAssets() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/alerts-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Alerts Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Gauge className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Event Rule: Catch Speeding Assets</h1>
          <p className="text-lg text-slate-600">
            Set up comprehensive speed monitoring alerts to catch vehicles exceeding speed limits and improve fleet
            safety.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Overview</h2>
          <p>
            Speed monitoring is one of the most critical safety features in fleet management. This guide will help you
            set up effective speeding alerts that balance safety enforcement with practical operational needs.
          </p>

          <h3>Why Speed Monitoring Matters</h3>
          <ul>
            <li>
              <strong>Safety:</strong> Reduce accident risk and protect drivers
            </li>
            <li>
              <strong>Legal Compliance:</strong> Avoid traffic violations and fines
            </li>
            <li>
              <strong>Insurance Benefits:</strong> Lower premiums through safer driving
            </li>
            <li>
              <strong>Fuel Efficiency:</strong> Reduce fuel consumption
            </li>
            <li>
              <strong>Vehicle Maintenance:</strong> Reduce wear and tear
            </li>
            <li>
              <strong>Company Reputation:</strong> Maintain professional image
            </li>
          </ul>

          <h2>Types of Speed Monitoring</h2>

          <h3>1. Posted Speed Limit Monitoring</h3>
          <p>Automatically detects when vehicles exceed posted speed limits using GPS and speed limit databases.</p>
          <ul>
            <li>
              <strong>Advantages:</strong> Accurate, legally relevant, comprehensive coverage
            </li>
            <li>
              <strong>Best for:</strong> General fleet monitoring, compliance reporting
            </li>
            <li>
              <strong>Considerations:</strong> Requires updated speed limit database
            </li>
          </ul>

          <h3>2. Custom Speed Threshold Monitoring</h3>
          <p>Set your own speed limits regardless of posted limits.</p>
          <ul>
            <li>
              <strong>Advantages:</strong> Company-specific policies, consistent across all areas
            </li>
            <li>
              <strong>Best for:</strong> Conservative safety policies, specific vehicle types
            </li>
            <li>
              <strong>Considerations:</strong> May be more restrictive than legal limits
            </li>
          </ul>

          <h3>3. Zone-Based Speed Monitoring</h3>
          <p>Different speed limits for different areas or geofences.</p>
          <ul>
            <li>
              <strong>Advantages:</strong> Context-aware, flexible policies
            </li>
            <li>
              <strong>Best for:</strong> Mixed urban/highway operations, customer sites
            </li>
            <li>
              <strong>Considerations:</strong> Requires geofence setup and maintenance
            </li>
          </ul>

          <h2>Setting Up Speed Monitoring Rules</h2>

          <h3>Step 1: Choose Your Speed Monitoring Type</h3>

          <h4>For Posted Speed Limit Monitoring:</h4>
          <ol>
            <li>Navigate to Event Rules → Create New Rule</li>
            <li>Select "Speed Limit Violation" template</li>
            <li>Choose "Posted Speed Limit" as reference</li>
            <li>Set tolerance level (e.g., 5 mph over limit)</li>
          </ol>

          <h4>For Custom Speed Threshold:</h4>
          <ol>
            <li>Create new custom event rule</li>
            <li>Set trigger: "Speed exceeds threshold"</li>
            <li>Define speed limit (e.g., 65 mph)</li>
            <li>Apply to selected vehicles or groups</li>
          </ol>

          <h3>Step 2: Configure Speed Parameters</h3>

          <h4>Speed Threshold Settings</h4>
          <ul>
            <li>
              <strong>Base Speed Limit:</strong> The maximum allowed speed
              <ul>
                <li>Posted limit + tolerance (e.g., 65 + 5 = 70 mph)</li>
                <li>Fixed company limit (e.g., 60 mph everywhere)</li>
                <li>Variable by vehicle type</li>
              </ul>
            </li>
            <li>
              <strong>Tolerance Buffer:</strong> Grace margin above speed limit
              <ul>
                <li>Recommended: 3-7 mph for accuracy</li>
                <li>Consider GPS accuracy limitations</li>
                <li>Account for speedometer variations</li>
              </ul>
            </li>
          </ul>

          <h4>Duration Requirements</h4>
          <ul>
            <li>
              <strong>Minimum Duration:</strong> How long speeding must occur
              <ul>
                <li>Recommended: 15-30 seconds</li>
                <li>Prevents alerts from brief speed spikes</li>
                <li>Filters out GPS inaccuracies</li>
              </ul>
            </li>
            <li>
              <strong>Sustained Speeding:</strong> Extended violations
              <ul>
                <li>Different thresholds for longer violations</li>
                <li>Escalated alerts for persistent speeding</li>
              </ul>
            </li>
          </ul>

          <h3>Step 3: Set Vehicle and Driver Filters</h3>

          <h4>Vehicle Selection</h4>
          <ul>
            <li>
              <strong>All Vehicles:</strong> Fleet-wide monitoring
            </li>
            <li>
              <strong>Vehicle Groups:</strong> Department or type-specific
            </li>
            <li>
              <strong>Individual Vehicles:</strong> High-risk or new vehicles
            </li>
          </ul>

          <h4>Driver Considerations</h4>
          <ul>
            <li>
              <strong>New Drivers:</strong> Lower tolerance, more frequent alerts
            </li>
            <li>
              <strong>Experienced Drivers:</strong> Standard monitoring
            </li>
            <li>
              <strong>Emergency Vehicles:</strong> Special exemptions or rules
            </li>
          </ul>

          <h2>Advanced Speed Monitoring Features</h2>

          <h3>Graduated Alert System</h3>

          <h4>Level 1: Minor Speeding (5-10 mph over)</h4>
          <ul>
            <li>In-vehicle warning (if available)</li>
            <li>Log event for reporting</li>
            <li>No immediate external notification</li>
          </ul>

          <h4>Level 2: Moderate Speeding (10-15 mph over)</h4>
          <ul>
            <li>Email alert to supervisor</li>
            <li>Dashboard notification</li>
            <li>Driver coaching flag</li>
          </ul>

          <h4>Level 3: Severe Speeding (15+ mph over)</h4>
          <ul>
            <li>Immediate Email to manager</li>
            <li>Email with location details</li>
            <li>Escalation to safety department</li>
            <li>Possible immediate intervention</li>
          </ul>

          <h3>Context-Aware Monitoring</h3>

          <h4>Road Type Considerations</h4>
          <ul>
            <li>
              <strong>Highway:</strong> Higher tolerance for brief speeding
            </li>
            <li>
              <strong>Urban Areas:</strong> Stricter monitoring
            </li>
            <li>
              <strong>School Zones:</strong> Zero tolerance policy
            </li>
            <li>
              <strong>Construction Zones:</strong> Enhanced monitoring
            </li>
          </ul>

          <h4>Time-Based Adjustments</h4>
          <ul>
            <li>
              <strong>Rush Hour:</strong> More lenient due to traffic flow
            </li>
            <li>
              <strong>Night Time:</strong> Stricter monitoring for safety
            </li>
            <li>
              <strong>Weather Conditions:</strong> Adjusted limits (if data available)
            </li>
          </ul>

          <h2>Notification Configuration</h2>

          <h3>Immediate Alerts</h3>

          <h4>Real-Time Notifications</h4>
          <ul>
            <li>
              <strong>Email Alerts:</strong> For detailed information
              <ul>
                <li>Include map location</li>
                <li>Speed graph if available</li>
                <li>Driver information</li>
                <li>Historical context</li>
              </ul>
            </li>
            <li>
              <strong>Push Notifications:</strong> For urgent situations
              <ul>
                <li>Include: Vehicle ID, speed, location, time</li>
                <li>Keep message concise</li>
                <li>Include severity level</li>
              </ul>
            </li>
          </ul>

          <h3>Escalation Procedures</h3>

          <h4>Progressive Escalation</h4>
          <ol>
            <li>
              <strong>First Alert:</strong> Direct supervisor (immediate)
            </li>
            <li>
              <strong>Second Alert:</strong> Fleet manager (if no response in 15 minutes)
            </li>
            <li>
              <strong>Final Alert:</strong> Safety director (if no response in 30 minutes)
            </li>
          </ol>

          <h4>Severe Speeding Protocol</h4>
          <ul>
            <li>Immediate notification to all levels</li>
            <li>Automatic incident report creation</li>
            <li>Driver contact attempt</li>
            <li>Possible emergency response coordination</li>
          </ul>

          <h2>Reporting and Analytics</h2>

          <h3>Speed Violation Reports</h3>

          <h4>Daily Summary Reports</h4>
          <ul>
            <li>Total violations by vehicle</li>
            <li>Severity breakdown</li>
            <li>Top violating drivers</li>
            <li>Time and location patterns</li>
          </ul>

          <h4>Trend Analysis</h4>
          <ul>
            <li>Weekly/monthly violation trends</li>
            <li>Improvement tracking after coaching</li>
            <li>Seasonal pattern identification</li>
            <li>Route-specific analysis</li>
          </ul>

          <h3>Performance Metrics</h3>
          <ul>
            <li>
              <strong>Violation Rate:</strong> Violations per mile driven
            </li>
            <li>
              <strong>Severity Index:</strong> Average excess speed
            </li>
            <li>
              <strong>Improvement Rate:</strong> Reduction over time
            </li>
            <li>
              <strong>Compliance Score:</strong> Overall fleet performance
            </li>
          </ul>

          <h2>Best Practices</h2>

          <h3>Implementation Strategy</h3>
          <ul>
            <li>
              <strong>Start Conservative:</strong> Begin with higher tolerances
            </li>
            <li>
              <strong>Gradual Tightening:</strong> Reduce tolerances over time
            </li>
            <li>
              <strong>Driver Education:</strong> Explain the system and benefits
            </li>
            <li>
              <strong>Consistent Enforcement:</strong> Apply rules fairly across all drivers
            </li>
          </ul>

          <h3>Avoiding Alert Fatigue</h3>
          <ul>
            <li>Set appropriate thresholds to avoid excessive alerts</li>
            <li>Use cooldown periods between alerts</li>
            <li>Focus on persistent violations rather than brief spikes</li>
            <li>Provide context in notifications</li>
          </ul>

          <h3>Driver Engagement</h3>
          <ul>
            <li>Share speed performance data with drivers</li>
            <li>Recognize improvements and good performance</li>
            <li>Provide coaching rather than just punishment</li>
            <li>Involve drivers in setting reasonable policies</li>
          </ul>

          <h2>Troubleshooting Common Issues</h2>

          <h3>False Alerts</h3>
          <ul>
            <li>
              <strong>GPS Accuracy:</strong> Increase minimum duration requirements
            </li>
            <li>
              <strong>Speed Limit Data:</strong> Verify and update speed limit database
            </li>
            <li>
              <strong>Tunnel/Bridge Effects:</strong> Add location-based exceptions
            </li>
          </ul>

          <h3>Missing Alerts</h3>
          <ul>
            <li>
              <strong>Threshold Too High:</strong> Review and adjust speed limits
            </li>
            <li>
              <strong>Duration Too Long:</strong> Reduce minimum violation time
            </li>
            <li>
              <strong>Vehicle Assignment:</strong> Verify vehicles are included in rules
            </li>
          </ul>

          <h3>Driver Complaints</h3>
          <ul>
            <li>Review specific incidents with drivers</li>
            <li>Adjust thresholds if consistently unreasonable</li>
            <li>Provide clear policy documentation</li>
            <li>Ensure consistent application across fleet</li>
          </ul>

          <h2>Integration with Other Systems</h2>

          <h3>Driver Scoring Systems</h3>
          <ul>
            <li>Incorporate speed violations into driver scores</li>
            <li>Weight violations by severity</li>
            <li>Track improvement over time</li>
          </ul>

          <h3>Insurance and Compliance</h3>
          <ul>
            <li>Generate reports for insurance providers</li>
            <li>Document safety program effectiveness</li>
            <li>Support DOT compliance requirements</li>
          </ul>

          <h3>Maintenance Systems</h3>
          <ul>
            <li>Correlate speeding with vehicle wear</li>
            <li>Adjust maintenance schedules for high-speed vehicles</li>
            <li>Track fuel efficiency impacts</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
