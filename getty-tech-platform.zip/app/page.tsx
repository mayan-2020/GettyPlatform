import Component from "../getty-tech-platform"

export default function Page() {
  return <Component />
}
