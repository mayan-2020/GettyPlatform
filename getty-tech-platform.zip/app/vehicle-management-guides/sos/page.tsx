import { ArrowLeft, AlertTriangle } from "lucide-react"

export default function SOSGuide() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a
              href="/vehicle-management-guides"
              className="flex items-center text-white hover:text-blue-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Vehicle Management Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-red-100 text-red-600 mb-6">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">SOS Emergency System</h1>
          <p className="text-lg text-slate-600">
            Emergency response system that allows drivers to quickly alert fleet managers and emergency contacts in case
            of urgent situations.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>SOS Field Overview</h2>
          <p>
            The SOS field is added to the main overview to be easy to detect any issue the driver is facing. This
            prominent placement ensures that emergency situations can be quickly identified and responded to by fleet
            managers and emergency personnel.
          </p>

          <div className="my-8">
            <img
              src="/images/sos-field.png"
              alt="Vehicle SOS status indicator showing normal state with green icon"
              className="border border-gray-200 rounded-lg shadow-sm"
            />
          </div>

          <h2>Emergency Activation</h2>
          <p>
            Once the alarm button is pressed by the driver, the red icon will be activated in the SOS field. This visual
            indicator immediately alerts fleet managers to the emergency situation and triggers the emergency response
            protocol.
          </p>

          <h2>Notification System</h2>
          <p>
            When an SOS alert is activated, different types of notifications will be received by the receiver,
            including:
          </p>
          <ul>
            <li>
              <strong>Email Alerts:</strong> Immediate email notifications to designated emergency contacts
            </li>
            <li>
              <strong>Push Notifications:</strong> Real-time alerts to mobile devices and fleet management apps
            </li>
            <li>
              <strong>Dashboard Alerts:</strong> Visual and audio alerts on the main monitoring dashboard
            </li>
            <li>
              <strong>Escalation Notifications:</strong> Automatic escalation to supervisors if initial alerts are not
              acknowledged
            </li>
          </ul>

          <h2>Emergency Response Features</h2>
          <ul>
            <li>
              <strong>Location Tracking:</strong> Immediate GPS location sharing when SOS is activated
            </li>
            <li>
              <strong>Two-Way Communication:</strong> Ability to communicate with the driver during emergency
            </li>
            <li>
              <strong>Emergency Contacts:</strong> Automatic notification to pre-configured emergency contacts
            </li>
            <li>
              <strong>Incident Documentation:</strong> Automatic logging of emergency events for review and analysis
            </li>
          </ul>

          <h2>SOS Status Indicators</h2>
          <ul>
            <li>
              <strong>Green Icon:</strong> Normal operation, no emergency
            </li>
            <li>
              <strong>Red Icon:</strong> Emergency activated, immediate attention required
            </li>
            <li>
              <strong>Flashing Red:</strong> Critical emergency with escalated priority
            </li>
          </ul>

          <h2>Best Practices</h2>
          <ul>
            <li>Train drivers on proper SOS system usage and when to activate alerts</li>
            <li>Regularly test the SOS system to ensure proper functionality</li>
            <li>Maintain updated emergency contact information</li>
            <li>Establish clear emergency response procedures for different types of situations</li>
            <li>Monitor SOS system performance and response times</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
