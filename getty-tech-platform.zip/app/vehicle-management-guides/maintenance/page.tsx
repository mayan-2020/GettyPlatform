import { ArrowLeft, Wrench } from "lucide-react"

export default function MaintenanceGuide() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a
              href="/vehicle-management-guides"
              className="flex items-center text-white hover:text-blue-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Vehicle Management Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Wrench className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Vehicle Maintenance Management</h1>
          <p className="text-lg text-slate-600">
            Automated maintenance reminders to keep your fleet in optimal condition with scheduled notifications based
            on mileage or time intervals.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Overview</h2>
          <p>
            Maintenance is used as a reminder system to maintain your vehicles properly and ensure optimal performance.
            The system tracks vehicle usage and automatically notifies you when maintenance is due, helping you stay on
            top of essential vehicle care tasks.
          </p>

          <h2>How Maintenance Reminders Work</h2>
          <p>
            The maintenance system operates on a simple but effective cycle. For example, when setting up an oil change
            reminder:
          </p>
          <ol>
            <li>You specify the maintenance interval (e.g., every 5,000 km or every 6 months)</li>
            <li>The system continuously monitors the vehicle's mileage and time</li>
            <li>Once the car achieves the specified kilometers or time period, you will be notified</li>
            <li>After the oil is changed, you log the maintenance completion in the system</li>
            <li>The data is recorded and the system automatically schedules the next maintenance event</li>
          </ol>

          <h2>Maintenance Scheduling Options</h2>
          <p>The maintenance system offers flexible scheduling based on your specific needs:</p>

          <h3>Kilometer-Based Maintenance</h3>
          <ul>
            <li>
              <strong>Oil Changes:</strong> Every 5,000-10,000 km depending on vehicle type
            </li>
            <li>
              <strong>Tire Rotation:</strong> Every 8,000-12,000 km
            </li>
            <li>
              <strong>Brake Inspection:</strong> Every 20,000-30,000 km
            </li>
            <li>
              <strong>Major Service:</strong> Every 50,000-100,000 km
            </li>
          </ul>

          <h3>Time-Based Maintenance</h3>
          <ul>
            <li>
              <strong>Daily Inspections:</strong> Pre-trip safety checks
            </li>
            <li>
              <strong>Weekly Maintenance:</strong> Fluid level checks, tire pressure
            </li>
            <li>
              <strong>Monthly Service:</strong> Comprehensive vehicle inspection
            </li>
            <li>
              <strong>Annual Requirements:</strong> Registration renewal, emissions testing
            </li>
          </ul>

          <h2>Maintenance Types and Examples</h2>

          <h3>Engine Maintenance</h3>
          <ul>
            <li>Oil and filter changes</li>
            <li>Air filter replacement</li>
            <li>Spark plug replacement</li>
            <li>Coolant system service</li>
          </ul>

          <h3>Safety Systems</h3>
          <ul>
            <li>Brake system inspection and service</li>
            <li>Tire replacement and rotation</li>
            <li>Light and electrical system checks</li>
            <li>Steering and suspension inspection</li>
          </ul>

          <h3>Regulatory Compliance</h3>
          <ul>
            <li>Vehicle registration renewal</li>
            <li>Safety inspections</li>
            <li>Emissions testing</li>
            <li>Commercial vehicle DOT inspections</li>
          </ul>

          <h2>Notification System</h2>
          <p>When maintenance is due, the system provides multiple notification methods:</p>
          <ul>
            <li>
              <strong>Dashboard Alerts:</strong> Visual indicators on the main interface
            </li>
            <li>
              <strong>Email Notifications:</strong> Detailed maintenance reminders sent to fleet managers
            </li>
            <li>
              <strong>Mobile Alerts:</strong> Push notifications to mobile devices
            </li>
            <li>
              <strong>Advanced Warnings:</strong> Notifications before maintenance is actually due
            </li>
          </ul>

          <h2>Maintenance Logging and Tracking</h2>
          <p>Once maintenance is completed, the system provides comprehensive logging capabilities:</p>
          <ul>
            <li>
              <strong>Service Records:</strong> Complete history of all maintenance performed
            </li>
            <li>
              <strong>Cost Tracking:</strong> Monitor maintenance expenses per vehicle
            </li>
            <li>
              <strong>Vendor Information:</strong> Track which service providers performed work
            </li>
            <li>
              <strong>Parts and Materials:</strong> Record parts used and materials consumed
            </li>
          </ul>

          <h2>Benefits of Automated Maintenance Management</h2>
          <ul>
            <li>
              <strong>Prevent Breakdowns:</strong> Regular maintenance reduces unexpected failures
            </li>
            <li>
              <strong>Extend Vehicle Life:</strong> Proper maintenance increases vehicle longevity
            </li>
            <li>
              <strong>Reduce Costs:</strong> Preventive maintenance is less expensive than emergency repairs
            </li>
            <li>
              <strong>Ensure Safety:</strong> Regular inspections keep vehicles safe for drivers and other road users
            </li>
            <li>
              <strong>Maintain Compliance:</strong> Stay current with regulatory requirements
            </li>
            <li>
              <strong>Improve Efficiency:</strong> Well-maintained vehicles operate more efficiently
            </li>
          </ul>

          <h2>Setting Up Maintenance Schedules</h2>
          <ol>
            <li>
              <strong>Define Maintenance Tasks:</strong> List all required maintenance for each vehicle type
            </li>
            <li>
              <strong>Set Intervals:</strong> Determine appropriate mileage or time intervals
            </li>
            <li>
              <strong>Configure Notifications:</strong> Set up who receives maintenance alerts
            </li>
            <li>
              <strong>Establish Procedures:</strong> Create workflows for completing and logging maintenance
            </li>
            <li>
              <strong>Train Staff:</strong> Ensure team members understand the maintenance system
            </li>
          </ol>

          <h2>Best Practices</h2>
          <ul>
            <li>Set up maintenance schedules as soon as vehicles are added to the fleet</li>
            <li>Use manufacturer recommendations as a starting point for intervals</li>
            <li>Adjust schedules based on vehicle usage patterns and operating conditions</li>
            <li>Keep detailed records of all maintenance performed</li>
            <li>Review maintenance data regularly to identify trends and optimize schedules</li>
            <li>Plan maintenance during scheduled downtime to minimize operational impact</li>
          </ul>

          <h2>Reporting and Analysis</h2>
          <p>The maintenance system provides valuable reporting capabilities:</p>
          <ul>
            <li>
              <strong>Maintenance History:</strong> Complete service records for each vehicle
            </li>
            <li>
              <strong>Cost Analysis:</strong> Track maintenance expenses and identify cost trends
            </li>
            <li>
              <strong>Performance Metrics:</strong> Monitor maintenance compliance and effectiveness
            </li>
            <li>
              <strong>Predictive Analytics:</strong> Identify vehicles that may need additional attention
            </li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
