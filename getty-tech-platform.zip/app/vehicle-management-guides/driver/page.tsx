import { ArrowLeft, User } from "lucide-react"

export default function DriverGuide() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a
              href="/vehicle-management-guides"
              className="flex items-center text-white hover:text-blue-300 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Vehicle Management Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <User className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Driver Management</h1>
          <p className="text-lg text-slate-600">
            Manage driver assignments and track driver identification in your fleet management system.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Driver Field Display</h2>
          <p>
            A driver field is added next to the vehicle plate number in the system interface. This field automatically
            displays driver information when the vehicle is in use.
          </p>

          <div className="my-8">
            <img
              src="/images/driver-field.png"
              alt="Driver field interface showing driver information display"
              className="border border-gray-200 rounded-lg shadow-sm"
            />
          </div>

          <h2>How Driver Detection Works</h2>
          <p>
            Once the driver ID is detected when the vehicle is turned on, the driver name automatically shows in the
            driver field. This provides real-time visibility into who is operating each vehicle in your fleet.
          </p>

          <h2>Benefits of Driver Tracking</h2>
          <ul>
            <li>
              <strong>Real-time Identification:</strong> Know who is driving each vehicle at any given time
            </li>
            <li>
              <strong>Accountability:</strong> Track driver behavior and performance
            </li>
            <li>
              <strong>Security:</strong> Ensure only authorized drivers are operating vehicles
            </li>
            <li>
              <strong>Compliance:</strong> Meet regulatory requirements for driver tracking
            </li>
          </ul>

          <h2>Driver ID Detection Methods</h2>
          <p>The system can detect driver IDs through RFID cards or key fobs.</p>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
