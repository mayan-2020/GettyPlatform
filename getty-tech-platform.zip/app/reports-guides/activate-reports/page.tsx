import { ArrowLeft, BarChart3 } from "lucide-react"

export default function ActivateReports() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/reports-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Reports Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <BarChart3 className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Activate Reports</h1>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Accessing Reports</h2>
          <p>
            Reports requests are seen in the reports section in the platform. Contact the system administrators for
            customized reports.
          </p>

          <h2>Report Activation Process</h2>
          <p>
            To activate reports in your fleet management system, follow these steps to enable the reporting
            functionality and start generating valuable insights from your fleet data.
          </p>

          <h3>Step 1: Navigate to Reports Section</h3>
          <ol>
            <li>Log into your fleet management dashboard</li>
            <li>Navigate to the "Reports" section in the main menu</li>
            <li>Review available report types and templates</li>
          </ol>

          <h3>Step 2: Enable Report Generation</h3>
          <ol>
            <li>Access the report settings or configuration panel</li>
            <li>Enable the specific report types you need</li>
            <li>Configure data sources and parameters</li>
            <li>Set up user permissions for report access</li>
          </ol>

          <h3>Step 3: Configure Report Parameters</h3>
          <ul>
            <li>
              <strong>Data Range:</strong> Set the time periods for report generation
            </li>
            <li>
              <strong>Vehicle Selection:</strong> Choose which vehicles to include
            </li>
            <li>
              <strong>Report Frequency:</strong> Set how often reports are generated
            </li>
            <li>
              <strong>Output Format:</strong> Select preferred formats (PDF, Excel, CSV)
            </li>
          </ul>

          <h3>Custom Reports</h3>
          <p>
            For specialized reporting needs that go beyond standard templates, contact your system administrators who
            can create customized reports tailored to your specific requirements.
          </p>

          <h2>Best Practices</h2>
          <ul>
            <li>Start with standard reports before requesting custom ones</li>
            <li>Regularly review and update report parameters</li>
            <li>Ensure proper user permissions are set</li>
            <li>Test reports with sample data before full deployment</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
