import { ArrowLeft, Mail } from "lucide-react"

export default function ScheduleReportsEmail() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/reports-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Reports Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Mail className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">
            Schedule reports to be sent automatically via email
          </h1>
          <p className="text-lg text-slate-600">
            This guide shows you how to create reports to be sent automatically via email.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Configuration</h2>

          <ol>
            <li>
              In your application, go to <strong>Main Menu</strong> → <strong>Reports</strong> →{" "}
              <strong>Manage Reports</strong>, or{" "}
              <a href="#" className="text-blue-600 hover:text-blue-700">
                generate an instance of your report
              </a>{" "}
              by following steps 1 to 4 of the guide.
            </li>

            <li>Select the report you would like to manage, and a new pop-up window will appear.</li>

            <li>Select the Schedule option from the left when editing the report.</li>

            <li>
              Enable the <strong>Scheduling active</strong> toggle to the right.
            </li>
          </ol>

          <h2>Additional Configuration Options</h2>
          <p>Once you have enabled scheduling, you can configure additional options such as:</p>
          <ul>
            <li>Email recipients</li>
            <li>Schedule frequency (daily, weekly, monthly)</li>
            <li>Time of delivery</li>
            <li>Report format preferences</li>
            <li>Custom email subject and message</li>
          </ul>

          <h2>Best Practices</h2>
          <ul>
            <li>Test the scheduled report with a small group before rolling out to all recipients</li>
            <li>Choose appropriate delivery times that align with business needs</li>
            <li>Regularly review and update recipient lists</li>
            <li>Monitor delivery success and address any failed deliveries</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
