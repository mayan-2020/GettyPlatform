import { ArrowLeft, FileSpreadsheet } from "lucide-react"

export default function DownloadExcelData() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/reports-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Reports Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <FileSpreadsheet className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Download reports with Excel data</h1>
          <p className="text-lg text-slate-600">
            Reporting data is now compatible with Microsoft Excel. Render and download your fleet data from the
            application and plug it into your company's Excel worksheet.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Step-by-Step Process</h2>

          <ol>
            <li>
              From the application, use the <strong>Main Menu</strong> to navigate to Reports. From there you can select{" "}
              <strong>Manage Reports</strong> to configure your reports. Or you can select an existing report from the
              list.
            </li>

            <li>
              Choose the <strong>Parameters</strong> that you would like to view. Select a custom date range, event
              rules, tags, and users.
            </li>

            <li>Run the report first to render and preview it on your screen.</li>

            <li>
              Once the report is rendered, you can either download it directly to your computer or choose to send it in
              an email.
            </li>
          </ol>

          <h2>Excel Download Options</h2>
          <p>When downloading reports, you have several format options available:</p>
          <ul>
            <li>
              <strong>Download Excel:</strong> Export data in Microsoft Excel format (.xlsx)
            </li>
            <li>
              <strong>Download CSV:</strong> Export as comma-separated values for spreadsheet compatibility
            </li>
            <li>
              <strong>Download CSV ZIP:</strong> Compressed CSV file for large datasets
            </li>
            <li>
              <strong>Download PDF:</strong> Export as PDF for sharing and printing
            </li>
          </ul>

          <h2>Benefits of Excel Format</h2>
          <ul>
            <li>
              <strong>Data Analysis:</strong> Use Excel's powerful analysis tools on your fleet data
            </li>
            <li>
              <strong>Custom Formatting:</strong> Apply your company's formatting and branding
            </li>
            <li>
              <strong>Integration:</strong> Easily integrate with existing Excel workflows and templates
            </li>
            <li>
              <strong>Calculations:</strong> Perform custom calculations and create additional metrics
            </li>
            <li>
              <strong>Charts and Graphs:</strong> Create visual representations of your data
            </li>
          </ul>

          <h2>Best Practices</h2>
          <ul>
            <li>Preview reports before downloading to ensure data accuracy</li>
            <li>Use appropriate date ranges to manage file sizes</li>
            <li>Consider using CSV format for very large datasets</li>
            <li>Save Excel files with descriptive names including date ranges</li>
            <li>Regularly backup important report data</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
