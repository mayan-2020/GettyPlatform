import { ArrowLeft, Navigation } from "lucide-react"

export default function TrackingToolGuides() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Platform
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Navigation className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Tracking Tool</h1>
          <p className="text-lg text-slate-600">
            Create temporary tracking links to share specific vehicle locations with external users for a limited time
            period.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Overview</h2>
          <p>
            The Tracking Tool is used to provide a temporary link to someone to view a specific vehicle for a specific
            time period. This feature allows you to share vehicle tracking information with clients, partners, or other
            stakeholders without giving them full access to your fleet management system.
          </p>

          <div className="my-8">
            <img
              src="/images/tracking-tool-interface.png"
              alt="Tracking Tool interface showing vehicle selection, date range settings, and QR code generation"
              className="border border-gray-200 rounded-lg shadow-sm w-full"
            />
          </div>

          <h2>How to Create a Tracking Link</h2>
          <p>Follow these steps to generate a temporary tracking link:</p>

          <h3>Step 1: Configure Tracking Parameters</h3>
          <ol>
            <li>
              <strong>Select Mode:</strong> Choose "Asset" to track a specific vehicle
            </li>
            <li>
              <strong>Choose Vehicle:</strong> Select the specific vehicle from the dropdown menu (e.g., "21E 20837 Land
              Cruiser")
            </li>
            <li>
              <strong>Set Valid From Date:</strong> Choose the start date and time when the link becomes active
            </li>
            <li>
              <strong>Set Valid To Date:</strong> Set the desired expire date and time when the link will no longer be
              accessible
            </li>
          </ol>

          <h3>Step 2: Generate the Tracking Code</h3>
          <ol>
            <li>Review all the parameters you've set</li>
            <li>Click on "Create tracking code" button</li>
            <li>A link will be created and can be shared with the intended recipient</li>
            <li>A QR code is also generated for easy mobile access</li>
          </ol>

          <h2>Key Features</h2>

          <h3>Automatic Expiration</h3>
          <ul>
            <li>
              <strong>Time-Limited Access:</strong> When the expiration date matches, the link will no longer be
              accessible
            </li>
            <li>
              <strong>Secure Sharing:</strong> Ensures temporary access without permanent system access
            </li>
            <li>
              <strong>Flexible Duration:</strong> Set any time period from hours to days or weeks
            </li>
          </ul>

          <h3>Manual Link Management</h3>
          <ul>
            <li>
              <strong>Early Deletion:</strong> In case you need to delete the link before the expire date, it can be
              easily deleted
            </li>
            <li>
              <strong>View Stored Codes:</strong> Access and manage all previously created tracking codes
            </li>
            <li>
              <strong>Link Control:</strong> Full control over who has access and for how long
            </li>
          </ul>

          <h2>Sharing Options</h2>
          <p>Once the tracking code is created, you have multiple ways to share it:</p>
          <ul>
            <li>
              <strong>Direct Link:</strong> Copy and share the generated URL via email, messaging, or other
              communication methods
            </li>
            <li>
              <strong>QR Code:</strong> Share the QR code for easy mobile scanning and access
            </li>
          </ul>

          <h2>Use Cases</h2>

          <h3>Customer Service</h3>
          <ul>
            <li>Share delivery vehicle location with customers</li>
            <li>Provide real-time updates on service technician arrival</li>
            <li>Allow clients to track their dedicated vehicles</li>
          </ul>

          <h3>Business Partners</h3>
          <ul>
            <li>Share vehicle locations with logistics partners</li>
            <li>Provide temporary access to contractors</li>
            <li>Coordinate with external service providers</li>
          </ul>

          <h3>Emergency Situations</h3>
          <ul>
            <li>Share vehicle location with emergency services</li>
            <li>Provide access to insurance companies for claims</li>
            <li>Coordinate with roadside assistance</li>
          </ul>

          <h2>Security and Privacy</h2>

          <h3>Access Control</h3>
          <ul>
            <li>
              <strong>Limited Scope:</strong> Recipients can only view the specific vehicle you've selected
            </li>
            <li>
              <strong>Time Restrictions:</strong> Access is automatically revoked after the expiration date
            </li>
            <li>
              <strong>No System Access:</strong> Recipients cannot access other parts of your fleet management system
            </li>
          </ul>

          <h3>Data Protection</h3>
          <ul>
            <li>
              <strong>Temporary Links:</strong> Links expire automatically to prevent unauthorized long-term access
            </li>
            <li>
              <strong>Controlled Information:</strong> Only location data for the specified vehicle is shared
            </li>
            <li>
              <strong>Audit Trail:</strong> Track who has been given access and when
            </li>
          </ul>

          <h2>Managing Tracking Codes</h2>

          <h3>View Stored Codes</h3>
          <p>Use the "View stored codes" button to:</p>
          <ul>
            <li>See all previously created tracking links</li>
            <li>Check expiration dates and status</li>
            <li>Delete links before their expiration date if needed</li>
            <li>Monitor usage and access patterns</li>
          </ul>

          <h3>Best Practices</h3>
          <ul>
            <li>Set appropriate expiration dates based on the specific use case</li>
            <li>Regularly review and clean up expired or unused tracking codes</li>
            <li>Use descriptive names or notes to identify the purpose of each link</li>
            <li>Inform recipients about the temporary nature of the access</li>
            <li>Monitor shared links to ensure they're being used appropriately</li>
          </ul>

          <h2>Benefits</h2>
          <ul>
            <li>
              <strong>Enhanced Customer Service:</strong> Provide transparency without compromising security
            </li>
            <li>
              <strong>Improved Communication:</strong> Share real-time information with stakeholders
            </li>
            <li>
              <strong>Operational Efficiency:</strong> Reduce customer inquiries about vehicle locations
            </li>
            <li>
              <strong>Flexible Access:</strong> Grant temporary access without permanent system permissions
            </li>
            <li>
              <strong>Professional Image:</strong> Demonstrate transparency and modern technology capabilities
            </li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
