import { ArrowLeft, Shield } from "lucide-react"

export default function AccessLevelUsers() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Platform
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Shield className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Access Level Users</h1>
          <p className="text-lg text-slate-600">
            Configure user access levels and security permissions for different roles and set up subaccounts for
            clients.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Setting Up a Subaccount for a Client</h2>
          <p>
            Follow these steps to create a restricted access account for clients that only shows specific vehicles and
            data.
          </p>

          <h3>Step 1: Create a Tag</h3>
          <p>
            Start by creating a tag to group the vehicles you want the client to access. This helps with organizing and
            filtering within the platform.
          </p>
          <ol>
            <li>Navigate to the Tags management section</li>
            <li>Click "Create New Tag"</li>
            <li>Give the tag a descriptive name (e.g., "Client_ABC_Vehicles")</li>
            <li>Save the tag</li>
          </ol>

          <h3>Step 2: Create a View</h3>
          <p>
            Set up a view that defines what vehicles the client will see when they log in. Make sure it's linked to the
            tag you just created.
          </p>
          <ol>
            <li>Go to Views management</li>
            <li>Create a new view</li>
            <li>Link the view to the tag created in Step 1</li>
            <li>Configure the view settings as needed</li>
            <li>Save the view</li>
          </ol>

          <h3>Step 3: Add a New User</h3>
          <p>Create the user account that the client will use to access the system.</p>
          <ol>
            <li>Go to Admin → Manage users</li>
            <li>Click "Create new user"</li>
            <li>
              Fill in the required fields:
              <ul>
                <li>Username</li>
                <li>Password</li>
                <li>Email address</li>
                <li>Full name</li>
              </ul>
            </li>
            <li>Save the user with default settings</li>
          </ol>

          <h3>Step 4: Create a Role</h3>
          <p>Set up a custom role that defines the specific permissions for the client.</p>
          <ol>
            <li>Navigate to Admin → Roles</li>
            <li>Create a new role</li>
            <li>Take a copy of the "Operator" role as a starting point</li>
            <li>
              Configure the role settings:
              <ul>
                <li>
                  <strong>ReadView:</strong> Select the view created in Step 2
                </li>
                <li>
                  <strong>ReadData:</strong> Select the tag created in Step 1
                </li>
                <li>
                  <strong>Users:</strong> Select the user created in Step 3
                </li>
              </ul>
            </li>
            <li>Enter all other required details</li>
            <li>Save the role</li>
          </ol>

          <h3>Step 5: Remove User from Default Role</h3>
          <p>Ensure the client user only has access through the custom role you created.</p>
          <ol>
            <li>Return to the Manage Users panel</li>
            <li>Click on the user created in Step 3</li>
            <li>In the Roles section, deselect any default roles</li>
            <li>Ensure only the new custom role is selected</li>
            <li>Save the changes</li>
          </ol>

          <h3>Step 6: Test and Share Login Credentials</h3>
          <p>Verify the setup works correctly before sharing access with the client.</p>
          <ol>
            <li>Log out of your admin account</li>
            <li>Log in using the client's username and password</li>
            <li>Verify that only the intended vehicles are visible</li>
            <li>Test that the client can only access permitted features</li>
            <li>Once confirmed, send the credentials to the client via secure communication</li>
          </ol>

          <h2>Best Practices</h2>

          <h3>Security Considerations</h3>
          <ul>
            <li>Use strong passwords for client accounts</li>
            <li>Regularly review and update client permissions</li>
            <li>Monitor client account activity</li>
          </ul>

          <h3>Organization Tips</h3>
          <ul>
            <li>Use consistent naming conventions for tags, views, and roles</li>
            <li>Document which vehicles belong to which clients</li>
            <li>Keep a record of client access permissions</li>
            <li>Regularly audit client accounts and permissions</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
