import { ArrowLeft, Layers } from "lucide-react"

export default function MapLayers() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/workspace-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Workspace Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Layers className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Map Layers</h1>
          <p className="text-lg text-slate-600">
            Configure and customize different map layers to enhance your fleet tracking visualization.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <p>
            I notice the GPSGate support link you provided shows an error page ("oops - The page you were looking for
            doesn't exist"). The Map Layers article appears to be unavailable or moved.
          </p>

          <p>
            Could you please provide the actual content from the Map Layers article, or share a screenshot of the
            working page content? This will allow me to write the appropriate guide content for the Map Layers section.
          </p>

          <h2>What Map Layers Typically Include</h2>
          <p>While waiting for the specific content, map layers generally allow you to:</p>
          <ul>
            <li>Switch between different map types (satellite, terrain, street view)</li>
            <li>Add overlay information like traffic, weather, or points of interest</li>
            <li>Customize the visual appearance of your tracking interface</li>
            <li>Toggle various data layers on and off for better visibility</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
