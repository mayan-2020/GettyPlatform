import { ArrowLeft, Settings } from "lucide-react"

export default function CustomizeWorkspace() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/workspace-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Workspace Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Settings className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Customize your Workspace</h1>
          <p className="text-lg text-slate-600">
            Learn how to personalize your workspace layout, panels, and interface elements to optimize your workflow.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <h2>Workspace Overview</h2>
          <p>
            A Workspace is a specified layout of the user interface. You can create multiple Workspaces for different
            tasks.
          </p>

          <p>A Workspace keeps track of the following information:</p>
          <ul>
            <li>A list of positions and sizes</li>
            <li>Columns visible in lists</li>
            <li>Sort order in lists</li>
            <li>Current view</li>
          </ul>

          <h2>Default Workspaces</h2>
          <p>
            By default, a newly created application comes with <strong>two different workspaces</strong>:
          </p>
          <ul>
            <li>
              <strong>Default:</strong> The standard workspace layout
            </li>
            <li>
              <strong>All:</strong> An alternative workspace configuration
            </li>
          </ul>

          <h2>Managing Workspaces</h2>
          <p>You can access workspace management options through the workspace dropdown menu, which includes:</p>
          <ul>
            <li>
              <strong>Default:</strong> Switch to the default workspace
            </li>
            <li>
              <strong>All:</strong> Switch to the "All" workspace view
            </li>
            <li>
              <strong>Manage Users:</strong> Access user management from workspace context
            </li>
            <li>
              <strong>Manage workspaces...:</strong> Open the workspace management interface
            </li>
            <li>
              <strong>Workspace settings...:</strong> Configure current workspace settings
            </li>
            <li>
              <strong>Save:</strong> Save changes to the current workspace
            </li>
          </ul>

          <h2>Creating Custom Workspaces</h2>
          <p>To create a new workspace tailored to your specific needs:</p>
          <ol>
            <li>Access the workspace dropdown menu</li>
            <li>Select "Manage workspaces..."</li>
            <li>Create a new workspace with your desired configuration</li>
            <li>Customize panel positions, sizes, and visibility</li>
            <li>Save your workspace for future use</li>
          </ol>

          <h2>Workspace Customization Options</h2>
          <ul>
            <li>
              <strong>Panel Layout:</strong> Arrange panels according to your workflow
            </li>
            <li>
              <strong>Column Configuration:</strong> Choose which columns are visible in lists
            </li>
            <li>
              <strong>Sort Preferences:</strong> Set default sorting for data lists
            </li>
            <li>
              <strong>View Settings:</strong> Configure the default view for your workspace
            </li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
