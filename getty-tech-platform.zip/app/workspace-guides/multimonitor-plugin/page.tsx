import { ArrowLeft, Monitor } from "lucide-react"

export default function MultiMonitorPlugin() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-white">
      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <a href="/workspace-guides" className="flex items-center text-white hover:text-blue-300 transition-colors">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Workspace Guides
            </a>
            <div className="flex items-center">
              <img src="/images/getty-logo.png" alt="Getty Tech Logo" className="h-8 w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-blue-100 text-blue-600 mb-6">
            <Monitor className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-4">MultiMonitor plugin</h1>
          <p className="text-lg text-slate-600">
            MultiMonitor plugin allows you to show multiple maps on a different monitor.
          </p>
        </div>

        {/* Content */}
        <div className="prose prose-slate max-w-none">
          <p>
            With this plugin, you can pop out up to nine additional maps, either showing a static area of the map or
            follow a specific asset.
          </p>

          <h2>Setup</h2>
          <ol>
            <li>
              In <strong>Site Admin (Legacy)</strong> go to the <strong>Plugins</strong> &gt;{" "}
              <strong>My Plugins</strong> tab
            </li>
            <li>
              Click on <strong>Get More Plugins</strong>
            </li>
            <li>
              Install <strong>MultiMonitor</strong>
            </li>
            <li>
              Go to the <strong>Privileges and Features</strong> of your application and enable{" "}
              <strong>Multimonitor</strong> privilege
            </li>
          </ol>

          <h2>Benefits of MultiMonitor Setup</h2>
          <ul>
            <li>
              <strong>Enhanced Monitoring:</strong> View multiple areas simultaneously
            </li>
            <li>
              <strong>Asset Tracking:</strong> Follow specific vehicles on dedicated screens
            </li>
            <li>
              <strong>Improved Productivity:</strong> Monitor different regions without switching views
            </li>
            <li>
              <strong>Control Room Efficiency:</strong> Perfect for dispatch and monitoring centers
            </li>
            <li>
              <strong>Flexible Display:</strong> Up to nine additional map windows
            </li>
          </ul>

          <h2>Use Cases</h2>
          <ul>
            <li>
              <strong>Dispatch Centers:</strong> Monitor multiple service areas simultaneously
            </li>
            <li>
              <strong>Fleet Operations:</strong> Track different vehicle groups on separate screens
            </li>
            <li>
              <strong>Emergency Services:</strong> Monitor critical areas and response units
            </li>
            <li>
              <strong>Logistics:</strong> Track deliveries across different regions
            </li>
          </ul>

          <h2>Configuration Options</h2>
          <ul>
            <li>
              <strong>Static Area Display:</strong> Show a fixed geographic region
            </li>
            <li>
              <strong>Asset Following:</strong> Automatically track specific vehicles
            </li>
            <li>
              <strong>Multiple Windows:</strong> Open up to nine additional map views
            </li>
            <li>
              <strong>Independent Controls:</strong> Each monitor can have different zoom and focus
            </li>
          </ul>

          <h2>Best Practices</h2>
          <ul>
            <li>Plan your monitor layout based on operational needs</li>
            <li>Assign specific areas or assets to each monitor</li>
            <li>Ensure adequate screen resolution for clear map viewing</li>
            <li>Train operators on multi-monitor navigation</li>
            <li>Consider monitor positioning for optimal viewing angles</li>
          </ul>

          <h2>Technical Requirements</h2>
          <ul>
            <li>Multiple monitor hardware setup</li>
            <li>Sufficient graphics card capability</li>
            <li>Adequate system memory for multiple map instances</li>
            <li>Proper monitor calibration and positioning</li>
          </ul>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 px-6 mt-16">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-white mb-2">© 2024 Getty Tech. All rights reserved.</p>
          <p className="text-sm text-white mb-1">Comprehensive GPS tracking solutions for new business needs</p>
          <p className="text-sm text-white mb-2">Address: Italian Village 1 House No 283</p>
          <a href="https://gettysecure.com" className="text-sm text-blue-400 hover:text-blue-300">
            https://gettysecure.com
          </a>
        </div>
      </footer>
    </div>
  )
}
